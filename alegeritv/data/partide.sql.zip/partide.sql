-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 14, 2011 at 06:28 PM
-- Server version: 5.0.92
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `alegeri_1`
--

-- --------------------------------------------------------

--
-- Table structure for table `partide`
--

CREATE TABLE IF NOT EXISTS `partide` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `denumire` varchar(255) collate latin1_general_ci NOT NULL default '',
  `den_scurta` varchar(50) collate latin1_general_ci NOT NULL default '',
  `seo` varchar(100) collate latin1_general_ci NOT NULL default '',
  `descriere` text character set utf8,
  `poza` varchar(100) collate latin1_general_ci default NULL,
  `presedinte` varchar(50) collate latin1_general_ci default NULL,
  `fondat` varchar(50) collate latin1_general_ci default NULL,
  `ideologie` varchar(100) collate latin1_general_ci default NULL,
  `nr_membri` varchar(50) collate latin1_general_ci default NULL,
  `website` varchar(255) collate latin1_general_ci default NULL,
  `emailuri` varchar(255) collate latin1_general_ci default NULL,
  `id_bec` int(10) unsigned NOT NULL default '0',
  `minoritar` tinyint(1) NOT NULL default '0',
  `id_afiliere_europeana` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `seo` (`seo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=81 ;

--
-- Dumping data for table `partide`
--

INSERT INTO `partide` (`id`, `denumire`, `den_scurta`) VALUES
(1, 'Partidul Social Democrat', 'PSD'),
(2, 'Partidul Conservator', 'PC'),
(3, 'Partidul National Liberal', 'PNL'),
(4, 'Partidul Democrat', 'PD'),
(5, 'Partidul Romania Mare', 'PRM'),
(6, 'Uniunea Democrata Maghiara din Romania', 'UDMR'),
(7, 'Partidul National Taranesc Crestin Democrat', 'PNTCD'),
(8, 'Partidul Noua Generatie - Crestin Democrat', 'PNG-CD'),
(9, 'Forta Democrata', 'FD'),
(10, 'Actiunea Populara', 'AP'),
(11, 'Uniunea pentru Reconstructia Romaniei', 'URR'),
(12, 'Alianta Dreptate si Adevar - PNL-PD', 'Alianta DA - PNL-PD'),
(13, 'PSD+PUR', 'PSD+PUR'),
(14, 'Partidul Liberal Democrat', 'PLD'),
(15, 'Partidul Initiativa Nationala', 'PIN'),
(16, 'Alianta Populara Crestin Democrata', 'APCD'),
(17, 'Partidul Tineretului Democrat', 'PTD'),
(18, 'Partida Romilor', 'PR'),
(19, 'Partidul Verde', 'PV'),
(80, 'Partidul Muncitorilor', 'PM'),
(20, 'Partidul Alianta Socialista', 'AS'),
(21, 'Partidul Democrat Liberal', 'PD-L'),
(22, 'Uniunea Populara Social Crestina', 'UPSC'),
(23, 'Partidul Forta Civica', 'PFC'),
(24, 'Partidul Ecologist Roman', 'PER'),
(25, 'Forumul Democrat al Germanilor din Romania', 'FDGR'),
(26, 'Uniunea Pensionarilor si a solidaritatii sociale', 'UNIUNEA'),
(27, 'Partidul National Democrat Crestin', 'PNDC'),
(28, 'Partidul Pentru  Patrie', 'PP'),
(29, 'Partidul National Liberal (PNL+PNTCD)', 'PNLP'),
(30, 'Uniunea Culturala A Rutenilor Din Romania', 'UCRR'),
(31, 'Uniunea Ucrainenilor Din Romania', 'UUR'),
(32, 'Partidul Popular Si Al Protectiei Sociale', 'PPPS'),
(33, 'Partidul Socialist Roman', 'PSR'),
(34, 'Partidul Popular Din Romania', 'PPR'),
(35, 'Partidul Republican', 'PR'),
(36, 'Partidul Civic Maghiar - Magyar Polgari Part', 'PCMMPP'),
(37, 'Alianta Pentru Unitatea Rromilor', 'APUR'),
(38, 'Uniunea Croatilor Din Romania', 'UCR'),
(39, 'Alianta Pentru Municipiul Oltenita Pnl + Pntcd', 'APMOPP'),
(40, 'Partidul Romaniei Europene', 'PRE'),
(41, 'Uniunea Armenilor Din Romania', 'UAR'),
(42, 'Uniunea Democrata A Tatarilor Turco-musulmani Din Romania', 'UDTTMR'),
(43, 'Partidul Social Democrat Constantin Titel Petrescu', 'PSDCTP'),
(44, 'Alianta Romaneasca din Sfantu Gheorghe', 'ARDSG'),
(45, 'Alianta Pentru Unitatea Romanilor Din Orasul Covasna (PSD, PNL, PRM)', 'APURDOCPPP'),
(46, 'Alianta Romaneasca Pentru Judetul Covasna', 'ARPJC'),
(47, 'Partidul Renasterea Romaniei', 'PRR'),
(48, 'Asociatia Italienilor Din Romania Ro.as.it', 'RO.AS.IT'),
(49, 'Partidul Alternativa Ecologista', 'PAE'),
(50, 'Comunitatea Rusilor Lipoveni Din Romania', 'CRLR'),
(51, 'Uniunea Democrata A Ucrainenilor Din Romania', 'UDAUDR'),
(52, 'Uniunea Democratica A Slovacilor Si Cehilor Din Romania', 'UDSCR'),
(53, 'Uniunea Sarbilor Din Romania', 'USR'),
(54, 'Alianata Electorala Partidul Social Democrat - Partidul Romania Mare', 'AEPSDPRM'),
(55, 'Alianta Electorala Locala Pnl - Per - 2008 - Sangeorgiu De Mures', 'AELPPSDM'),
(56, 'Uniunea Elena Din Romania', 'UER'),
(57, 'Alianta Pentru Falticeni', 'APF'),
(58, 'Alianta Electorala PNTCD+PNL', 'AEP'),
(59, 'Alianta PNTCD-PNL Marginea', 'APM'),
(60, 'Alianta Pentru Timis', 'APT'),
(61, 'Uniunea Bulgara Din Banat Romania', 'UBBR'),
(62, 'Alianta electorala dintre Partidul Ecologist Roman si Partidul Verde', 'PVE'),
(66, 'Alianta Politica Partidul Social Democrat + Partidul Conservator', 'PSD+PC'),
(67, 'Asociatia Macedonenilor din Romania', 'AMR'),
(68, 'Asociatia Liga Albanezilor din Romania', 'ALAR'),
(70, 'Federatia Comunitatilor Evreiesti din Romania', 'FCER'),
(71, 'Uniunea Polonezilor din Romania', 'UPR'),
(72, 'Uniunea Democrata Turca din Romania', 'UDTR'),
(74, 'Alianta Partidul Popular European (Crestin Democrati) si Democrati Europeni', 'PPE-DE'),
(75, 'Partidul Socialist al Muncii', 'PSM'),
(76, 'Partidul Liberal Democrat Roman', 'PLDR'),
(77, 'Alianta pentru Romania', 'ApR'),
(78, 'Partidul Renasterea Nationala', 'PRN'),
(79, 'Partidul Democrat Social Roman', 'PDSR');
